-- by : @MuteTeam
function run(msg, matches) 
if matches[1] == "sticker" then
	if matches[3] == "black" then
local black = "http://api.roonx.com/photo/pic3.php?text=..matches[2]&color=black
local file = download_to_file(black,'mutetm.webp') 
reply_document(msg['id'], file, ok_cb, false) 
end 
	if matches[3] == "red" then
local red = "http://api.roonx.com/photo/pic3.php?text=..matches[2]&color=red
local file = download_to_file(red,'mutetm.webp') 
reply_document(msg['id'], file, ok_cb, false) 
end 
	if matches[3] == "blue" then
local blue = "http://api.roonx.com/photo/pic3.php?text=..matches[2]&color=blue
local file = download_to_file(blue,'mutetm.webp') 
reply_document(msg['id'], file, ok_cb, false) 
end 
end
end
return {               
patterns = {
"^[#/!](sticker) (.*) (.*)$"
},
run = run
}