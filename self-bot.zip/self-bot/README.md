# self-bot
سورس ربات سلف 2 زبانه !

روش نصب :
```
git clone https://github.com/MutePuker/self-bot
cd self-bot
chmod +x launch.sh
./launch.sh install
./launch.sh # phone number # code 
```
براي ادد كردن ربات در گروه پس از جوين شدن عبارت
<b>/add</b> 
را ارسال كنيد !

[developer👤](https://telegram.me/MutePuker)

[channel📢](https://telegram.me/MutePuker)

The stars do not ! ;)


Based on Taylor-Team
