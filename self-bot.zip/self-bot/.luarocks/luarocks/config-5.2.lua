rocks_trees = {
   { name = [[system]], root = [[/home/ubuntu/workspace/self-bot/.luarocks]] }
}
