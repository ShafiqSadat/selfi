rocks_trees = {
   { name = [[system]], root = [[/home/cabox/workspace/SignalTG/.luarocks]] }
}
