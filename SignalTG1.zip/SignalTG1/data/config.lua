do local _ = {
  about_text = "👑 AFBots 👑\nAn advanced administration bot based on TG-CLI written in Lua\n\n🔰 AFProtect 🔰\n\nAdmins:\n🔥 @ShafiqSadat 🔥\n\n🔥 @AFBots_admin 🔥\n\n🔥 AFTeam Bots 🔥\n\n\nSpecial thanks to\nSEEDTEAM\n\nOur channels\n@AFTeam\n",
  disabled_channels = {
    ["channel#id1052259291"] = false,
    ["channel#id1070296129"] = true,
    ["channel#id1077788783"] = false,
    ["channel#id1079897202"] = true,
    ["channel#id1080144534"] = false,
    ["channel#id1087685050"] = true,
    ["channel#id1095216324"] = false
  },
  enabled_plugins = {
    "Admin",
    "Anti_Spam",
    "Banhammer",
    "Broadcast",
    "Ingroup",
    "Inpm",
    "Inrealm",
    "Msg_Checks",
    "fal",
    "onoff",
    "chat2",
    "tabchi",  
    "jok",
    "mean",
    "echo",
    "lockfwd1",
    "salam",
    "chat"
  },
  help_text = "Commands list :\n\n!kick [username|id]\n🔵 اخراج شخص از گروه 🔴\n〰〰〰〰〰〰〰〰\n!ban [ username|id]\n🔵 مسدود کردن شخص از گروه 🔴\n〰〰〰〰〰〰〰〰\n!unban [id]\n🔵 خارج کردن فرد از لیست مسدودها 🔴\n〰〰〰〰〰〰〰〰\n!who\n🔵 لیست اعضای گروه 🔴\n〰〰〰〰〰〰〰〰\n!modlist\n🔵 لیست مدیران 🔴\n〰〰〰〰〰〰〰〰\n!promote [username]\n🔵 افزودن شخص به لیست مدیران 🔴\n〰〰〰〰〰〰〰〰\n!demote [username]\n🔵 خارج کردن شخص از لیست مدیران 🔴\n〰〰〰〰〰〰〰〰\n!kickme\n🔵 اخراج خود از گروه 🔴\n〰〰〰〰〰〰〰〰\n!about\n🔵 دریافت متن گروه 🔴\n〰〰〰〰〰〰〰〰\n!setphoto\n🔵 عوض کردن عکس گروه 🔴\n〰〰〰〰〰〰〰〰\n!setname [name]\n🔵 عوض کردن اسم گروه 🔴\n〰〰〰〰〰〰〰〰\n!rules\n🔵 دریافت قوانین گروه 🔴\n〰〰〰〰〰〰〰〰\n!id\n🔵 دریافت آیدی گروه یا شخص 🔴\n〰〰〰〰〰〰〰〰\n!help\n🔵 دریافت لیست دستورات 🔴\n〰〰〰〰〰〰〰〰\n!lock [links|flood|spam|Arabic|member|rtl|sticker|contacts|strict]\n🔵 قفل کردن تنظیمات 🔴\n〰〰〰〰〰〰〰〰\n!unlock [links|flood|spam|Arabic|member|rtl|sticker|contacts|strict]\n🔵 بازکردن قفل تنظیمات گروه 🔴\n〰〰〰〰〰〰〰〰\n!mute [all|audio|gifs|photo|video]\n🔵 بیصدا کردن فرمت ها 🔴\n〰〰〰〰〰〰〰〰\n!unmute [all|audio|gifs|photo|video]\n🔵 از حالت بیصدا درآوردن فرمت ها 🔴\n〰〰〰〰〰〰〰〰\n!set rules <text>\n🔵 تنظیم قوانین برای گروه 🔴\n〰〰〰〰〰〰〰〰\n!set about <text>\n🔵 تنظیم متن درباره ی گروه 🔴\n〰〰〰〰〰〰〰〰\n!settings\n🔵 مشاهده تنظیمات گروه 🔴\n〰〰〰〰〰〰〰〰\n!muteslist\n🔵 لیست فرمت های بیصدا 🔴\n〰〰〰〰〰〰〰〰\n!muteuser [username]\n🔵 بیصدا کردن شخص در گروه 🔴\n〰〰〰〰〰〰〰〰\n!mutelist\n🔵 لیست افراد بیصدا 🔴\n〰〰〰〰〰〰〰〰\n!newlink\n🔵 ساختن لینک جدید 🔴\n〰〰〰〰〰〰〰〰\n!link\n🔵 دریافت لینک گروه 🔴\n〰〰〰〰〰〰〰〰\n!owner\n🔵 مشاهده آیدی صاحب گروه 🔴\n〰〰〰〰〰〰〰〰\n!setowner [id]\n🔵 یک شخص را به عنوان صاحب گروه انتخاب کردن 🔴\n〰〰〰〰〰〰〰〰\n!setflood [value]\n🔵 تنظیم حساسیت اسپم 🔴\n〰〰〰〰〰〰〰〰\n!stats\n🔵 مشاهده آمار گروه 🔴\n〰〰〰〰〰〰〰〰\n!save [value] <text>\n🔵 افزودن دستور و پاسخ 🔴\n〰〰〰〰〰〰〰〰\n!get [value]\n🔵 دریافت پاسخ دستور 🔴\n〰〰〰〰〰〰〰〰\n!clean [modlist|rules|about]\n🔵 پاک کردن [مدیران ,قوانین ,متن گروه] 🔴\n〰〰〰〰〰〰〰〰\n!res [username]\n🔵 دریافت آیدی افراد 🔴\n💥 !res @username 💥\n〰〰〰〰〰〰〰〰\n!log\n🔵 لیست ورود اعضا 🔴\n〰〰〰〰〰〰〰〰\n!banlist\n🔵 لیست مسدود شده ها 🔴\n〰〰〰〰〰〰〰〰\n💥 شما میتوانید از / و ! و # استفاده کنید 💥\n",
  help_text_realm = "Realm Commands:\n\n!creategroup [Name]\n🔵 ساختن گروه 🔴\n〰〰〰〰〰〰〰〰\n!createrealm [Name]\n🔵 ساختن مقرفرماندهی 🔴\n〰〰〰〰〰〰〰〰\n!setname [Name]\n🔵 عوض کردن اسم مقرفرماندهی 🔴\n〰〰〰〰〰〰〰〰\n!setabout [group|sgroup] [GroupID] [Text]\n🔵 عوض کردن متن درباره ی گروه یا سوپرگروه 🔴\n〰〰〰〰〰〰〰〰\n!setrules [GroupID] [Text]\n🔵 قانونگذاری برای یک گروه 🔴\n〰〰〰〰〰〰〰〰\n!lock [GroupID] [setting]\n🔵 قفل کردن تنظیمات یک گروه 🔴\n〰〰〰〰〰〰〰〰\n!unlock [GroupID] [setting]\n🔵 باز کردن تنظیمات یک گروه 🔴\n〰〰〰〰〰〰〰〰\n!settings [group|sgroup] [GroupID]\n🔵 مشاهده تنظیمات یک گروه یا سوپرگروه 🔴\n〰〰〰〰〰〰〰〰\n!wholist\n🔵 مشاهده لیست اعضای گروه یا مقرفرماندهی 🔴\n〰〰〰〰〰〰〰〰\n!who\n🔵 دریافت فایل اغضای گروه یا مقرفرماندهی 🔴\n〰〰〰〰〰〰〰〰\n!type\n🔵 مشاهده ی نوع گروه 🔴\n〰〰〰〰〰〰〰〰\n!kill chat [GroupID]\n🔵 پاک کردن یک گروه و اعضای آن 🔴\n〰〰〰〰〰〰〰〰\n!kill realm [RealmID]\n🔵 پاک کردن یک مقرفرماندهی و اعضای آن 🔴\n〰〰〰〰〰〰〰〰\n!addadmin [id|username]\n🔵 ادمین کردن یک شخص در ربات (فقط برای سودو) 🔴\n〰〰〰〰〰〰〰〰\n!removeadmin [id|username]\n🔵 پاک کردن یک شخص از ادمینی در ربات (فقط برای سودو) 🔴\n〰〰〰〰〰〰〰〰\n!list groups\n🔵 مشهاده لیست گروه های ربات به همراه لینک آنها 🔴\n〰〰〰〰〰〰〰〰\n!list realms\n🔵 مشاهده لیست مقرهای فرماندهی به همراه لینک آنها 🔴\n〰〰〰〰〰〰〰〰\n!support\n🔵 افزودن شخص به پشتیبانی 🔴\n〰〰〰〰〰〰〰〰\n!-support\n🔵 پاک کردن شخص از پشتیبانی 🔴\n〰〰〰〰〰〰〰〰\n!log\n🔵 دریافت ورود اعضا به گروه یا مقرفرماندهی 🔴\n〰〰〰〰〰〰〰〰\n!broadcast [text]\n!broadcast Hello !\n🔵 ارسال متن به همه گروه های ربات (فقط مخصوص سودو) 🔴\n〰〰〰〰〰〰〰〰\n!bc [group_id] [text]\n!bc 123456789 Hello !\n🔵 ارسال متن به یک گروه مشخص 🔴\n〰〰〰〰〰〰〰〰\n💥 شما میتوانید از / و ! و # استفاده کنید 💥\n",
  help_text_super = "SuperGroup Commands:\n\n!gpinfo\n🔵 دریافت اطلاعات سوپرگروه 🔴\n!admins\n🔵 دریافت لیست ادمین های سوپرگروه 🔴\n!owner\n🔵 مشاهده آیدی صاحب گروه 🔴\n!modlist\n🔵 مشاهده لیست مدیران 🔴\n!bots\n🔵 مشهاده لیست بات های موجود در سوپرگروه 🔴\n!who\n🔵 مشاهده لیست کل اعضای سوپرگروه 🔴\n!block\n🔵 اخراج شخص از سوپرگروه 🔴\n!kick\n🔵 اخراج شخص از سوپرگروه 🔴\n!ban\n🔵 مسدود کردن شخص از سوپرگروه 🔴\n!unban\n🔵 خارج کردن شخص از لیست مسدودها 🔴\n!id\n🔵 مشاهده آیدی سوپرگروه یا شخص 🔴\n!id from\n🔵 گرفتن آیدی شخصی که از او فوروارد شده است 🔴\n!kickme\n🔵 اخراج خود از سوپرگروه 🔴\n!setowner\n🔵 یک شخص را به عنوان صاحب گروه انتخاب کردن 🔴\n!promote [username|id]\n🔵 افزودن یک شخص به لیست مدیران 🔴\n!demote [username|id]\n🔵 پاک کردن یک شخص از لیست مدیران 🔴\n!setname\n🔵 عوض کردن اسم گروه 🔴\n!setphoto\n🔵 عوض کردن عکس گروه 🔴\n!setrules\n🔵 قانونگذاری برای گروه 🔴\n!setabout\n🔵 عوض کردن متن درباره ی گروه 🔴\n!save [value] <text>\n🔵 افزودن دستور و پاسخ 🔴\n!get [value]\n🔵 دریافت پاسخ دستور 🔴\n!newlink\n🔵 ساختن لینک جدید 🔴\n!link\n🔵 دریافت لینک گروه 🔴\n!rules\n🔵 دریافت قوانین گروه 🔴\n!lock [links|flood|spam|Arabic|member|rtl|sticker|contacts|strict|tag|username|fwd|reply|fosh|tgservice|leave|join|emoji|english|media|operator]\n🔵 قفل کردن تنظیمات 🔴\n!unlock [links|flood|spam|Arabic|member|rtl|sticker|contacts|strict|tag|username|fwd|reply|fosh|tgservice|leave|join|emoji|english|media|operator]\n🔵 بازکردن قفل تنظیمات گروه 🔴\n!mute [all|audio|gifs|photo|video|service]\n🔵 بیصدا کردن فرمت ها 🔴\n!unmute [all|audio|gifs|photo|video|service]\n🔵 از حالت بیصدا خارج کردن فرمت ها 🔴\n!setflood [value]\n🔵 تنظیم حساسیت اسپم 🔴\n!type [name]\n🔵 تنظیم نوع گروه 🔴\n!settings\n🔵 مشاهده تنظیمات گروه 🔴\n!mutelist\n🔵 لیست افراد بیصدا 🔴\n!silent [username]\n🔵 بیصدا کردن شخص در گروه 🔴\n!silentlist\n🔵 لیست افراد بیصدا 🔴\n!banlist\n🔵 مشاهده لیست مسدود شده ها 🔴\n!clean [rules|about|modlist|silentlist|badwords]\n🔵 پاک کردن [مدیران ,قوانین ,متن گروه,لیست بیصداها, لیست کلمات غیرمجاز] 🔴\n!del\n🔵 پاک کردن پیام با ریپلی 🔴\n!addword [word]\n🔵 افزودن کلمه به لیست کلمات غیرمجاز🔴\n!remword [word]\n🔵 پاک کردن کلمه از لیست کلمات غیرمجاز 🔴\n!badwords\n🔵 مشاهده لیست کلمات غیرمجاز 🔴\n!clean msg [value]\n🔵 پاک کردن تعداد پیام مورد نظر 🔴\n!public [yes|no]\n🔵 همگانی کردن گروه 🔴\n!res [username]\n🔵 به دست آوردن آیدی یک شخص 🔴\n!log\n🔵 لیست ورود اعضا 🔴\n〰〰〰〰〰〰〰〰\n💥 شما میتوانید از / و ! و # استفاده کنید 💥\n💥AFTeam @AFBots_admin💥\n",
  moderation = {
    data = "data/moderation.json"
  },
  sudo_users = {
    113566842
  }
}
return _
end