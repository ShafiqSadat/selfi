local function maxteam(msg,matches)
if matches[1] == 'setmyrank' then 
if string.len(matches[2]) > 20 and not is_sudo(msg) then 
return 'جمله شما بزرگ است!' 
end 
if msg.text then 
if msg.text:lower():match('developer') and not is_sudo(msg) then 
return 'شما از کلمه (developer) استفاده کردید این کلمه ممنوع است!' 
end 
end 
local id = msg.from.id 
redis:hset('rank:user',id,matches[2]) 
return 'مقام شما ثبت شد' 
end 
if matches[1] == 'myrank' then 
local id = msg.from.id 
local rank = redis:hget('rank:user',id) 
reply_msg(msg.id,rank,ok_cb,false) 
if not rank then 
return 'شما برای خودتان مقامی ثبت نکرده اید!' 
end 
end
end

return {
patterns = {
'^[#!/]([Ss]etmyrank) (.*)$',
'^[#!/]([Mm]yrank)$',
},
run = maxteam,
}

--By @MosyDev
--Channel: @MaxTeamCh