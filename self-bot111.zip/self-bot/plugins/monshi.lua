 -- @black1m
 local function run(msg, matches) 
if matches[1] == "setpm" then 
if not is_sudo(msg) then 
return 'شما سودو نیستید' 
end 
local pm = matches[2] 
redis:set('bot:pm',pm) 
return 'متن پاسخ گویی ثبت شد' 
end 

if matches[1] == "pm" and is_sudo(msg) then
local hash = ('bot:pm') 
    local pm = redis:get(hash) 
    if not pm then 
    return ' ثبت نشده' 
    else 
    reply_msg(msg.id, 'پیغام کنونی منشی:\n\n'..pm, ok_cb, false)
    end
end

if matches[1]=="monshi" then 
if not is_sudo(msg) then 
return 'شما سودو نیستید' 
end 
if matches[2]=="on"then 
redis:set("bot:pm", "no pm")
return "منشی فعال شد لطفا دوباره پیغام را تنظیم کنید" 
end 
if matches[2]=="off"then 
redis:del("bot:pm")
return "منشی غیرفعال شد" 
end
 end

  if msg.to.type == "user" and msg.text then
    local hash = ('bot:pm') 
    local pm = redis:get(hash)
if msg.from.id == ایدی عددی شما or msg.to.type == 'channel' or msg.to.type == 'chat' then
return
else
    reply_msg(msg.id, pm, ok_cb, false)
    end 
    end
end
return { 
patterns ={ 
"^[!#/](setpm) (.*)$", 
"^[!#/](monshi) (on)$", 
"^[!#/](monshi) (off)$", 
"^[!#/](pm)$", 
"^(.*)$", 
}, 
run = run 
}
-- @speed_tg_ch
-- @PluginLua
